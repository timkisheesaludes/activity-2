<?php
$conn = new mysqli('localhost', 'root', '', 'login');

$popup_message = '';
$popup_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    // Check if email already exists
    $check = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $check->bind_param("s", $email);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        $popup_message = "⚠️ This email is already registered.";
        $popup_type = "error";
    } else {
        $stmt = $conn->prepare("INSERT INTO users (email, password) VALUES (?, ?)");
        $stmt->bind_param("ss", $email, $password);

        if ($stmt->execute()) {
            $popup_message = "✅ Registration successful. You can now log in.";
            $popup_type = "success";
        } else {
            $popup_message = "❌ Registration failed. Please try again.";
            $popup_type = "error";
        }
        $stmt->close();
    }
    $check->close();
}
?>

<link rel="stylesheet" href="style.css">
<style>
    .popup {
        background-color: #333;
        padding: 10px;
        margin-bottom: 15px;
        border-left: 5px solid;
        border-radius: 4px;
    }
    .popup.success { border-color: #03dac6; color: #03dac6; }
    .popup.error   { border-color: #f44336; color: #f44336; }
</style>

<form method="POST">
    <h2>Register</h2>

    <?php if ($popup_message): ?>
        <div class="popup <?= $popup_type ?>"><?= $popup_message ?></div>
    <?php endif; ?>

    <input type="email" name="email" placeholder="Email" required>
    <input type="password" name="password" placeholder="Password" required>
    <button type="submit">Register</button>
    <p><a href="login.php" style="color: #03dac6;">Back to login</a></p>
</form>

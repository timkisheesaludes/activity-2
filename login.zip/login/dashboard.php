<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
?>

<link rel="stylesheet" href="style.css">
<div style="text-align:center; margin-top: 50px;">
    <h1>Welcome to your Dashboard</h1>
    <p>You are logged in successfully.</p>
    <a href="logout.php" style="color: #03dac6;">Logout</a>
</div>

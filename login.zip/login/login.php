<?php
session_start();
$conn = new mysqli('localhost', 'root', '', 'login');

function can_attempt($user_id, $conn) {
    $count = 0; // Initialize to avoid Intelephense warning
    $stmt = $conn->prepare("SELECT COUNT(*) FROM log_in_attempt WHERE user_id=? AND attempt='failed' AND time > NOW() - INTERVAL 5 MINUTE");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();
    return $count < 5;
}

function get_user_id($email, $conn) {
    $id = null; // Initialize to avoid Intelephense warning
    $stmt = $conn->prepare("SELECT id FROM users WHERE email=?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->bind_result($id);
    $stmt->fetch();
    $stmt->close();
    return $id;
}

$popup_message = '';
$popup_type = ''; // success or error

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    $user_id = get_user_id($email, $conn);
    if ($user_id === null) {
        $popup_message = "❌ Invalid credentials.";
        $popup_type = 'error';
    } else {
        if (!can_attempt($user_id, $conn)) {
            $popup_message = "🔒 Too many login attempts. Try again in 5 minutes.";
            $popup_type = 'error';
        } else {
            $hashed = ''; // Initialize to avoid potential warning
            $stmt = $conn->prepare("SELECT password FROM users WHERE id=?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $stmt->bind_result($hashed);
            $stmt->fetch();
            $stmt->close();

            if ($hashed && password_verify($password, $hashed)) {
                $stmt = $conn->prepare("INSERT INTO log_in_attempt (user_id, attempt) VALUES (?, 'success')");
                $stmt->bind_param("i", $user_id);
                $stmt->execute();
                $stmt->close();

                $_SESSION['user_id'] = $user_id;
                header("Location: dashboard.php");
                exit;
            } else {
                $stmt = $conn->prepare("INSERT INTO log_in_attempt (user_id, attempt) VALUES (?, 'failed')");
                $stmt->bind_param("i", $user_id);
                $stmt->execute();
                $stmt->close();

                $popup_message = "❌ Incorrect password.";
                $popup_type = 'error';
            }
        }
    }
}
?>

<link rel="stylesheet" href="style.css">
<style>
    .popup {
        background-color: #333;
        padding: 10px;
        margin-bottom: 15px;
        border-left: 5px solid;
        border-radius: 4px;
    }
    .popup.success { border-color: #03dac6; color: #03dac6; }
    .popup.error   { border-color: #f44336; color: #f44336; }
</style>

<form method="POST">
    <h2>Login</h2>

    <?php if ($popup_message): ?>
        <div class="popup <?= $popup_type ?>"><?= $popup_message ?></div>
    <?php endif; ?>

    <input type="email" name="email" placeholder="Email" required>
    <input type="password" name="password" placeholder="Password" required>
    <button type="submit">Login</button>
    <p><a href="register.php" style="color: #03dac6;">Register</a> if you don't have an account.</p>
</form>

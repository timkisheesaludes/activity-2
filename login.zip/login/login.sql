-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 25, 2025 at 08:34 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `login`
--

-- --------------------------------------------------------

--
-- Table structure for table `log_in_attempt`
--

CREATE TABLE `log_in_attempt` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `attempt` enum('success','failed') NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `log_in_attempt`
--

INSERT INTO `log_in_attempt` (`id`, `user_id`, `attempt`, `time`) VALUES
(1, 1, 'failed', '2025-04-25 06:28:38'),
(2, 1, 'failed', '2025-04-25 06:28:59'),
(3, 1, 'failed', '2025-04-25 06:30:14'),
(4, 1, 'failed', '2025-04-25 06:30:17'),
(5, 1, 'failed', '2025-04-25 06:30:36'),
(6, 2, 'success', '2025-04-25 06:32:20'),
(7, 4, 'failed', '2025-04-25 06:33:45'),
(8, 4, 'failed', '2025-04-25 06:33:48'),
(9, 4, 'failed', '2025-04-25 06:33:51'),
(10, 4, 'failed', '2025-04-25 06:33:55'),
(11, 4, 'failed', '2025-04-25 06:33:57');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`) VALUES
(1, 'tim@gmail.com', '$2y$10$PWgKUD5xU3g.N1oZ3YZuXOqOdLGO8lEaVKEjVq62xmRekZOMz8nOm'),
(2, 'tung@gmail.com', '$2y$10$KblQmoowZj6I99X3tEg20On0kqhlQCVrmF3Dg2PezYek9QInKfQ52'),
(4, 'kish@gmail.com', '$2y$10$iMY94.PO0Y0CcV9/zlYO6ejQzzdNjhTZlfycDlul4mFLGQb40.JK6');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `log_in_attempt`
--
ALTER TABLE `log_in_attempt`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `log_in_attempt`
--
ALTER TABLE `log_in_attempt`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `log_in_attempt`
--
ALTER TABLE `log_in_attempt`
  ADD CONSTRAINT `log_in_attempt_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
